import {test} from 'node:test';
import assert from 'node:assert/strict';
import {WebSocket} from 'ws';
import {createRelay} from './server.mjs';

test('codes, host symmetry, room isolation, versions, capacity, routing and cleanup',async()=>{
 const relay=createRelay(); await new Promise(r=>relay.server.listen(0,'127.0.0.1',r));
 const url=`ws://127.0.0.1:${relay.server.address().port}`; const clients=[];
 async function connect(message) {
   const ws=new WebSocket(url); clients.push(ws); ws.queue=[]; ws.waiters=[];
   ws.on('message',raw=>{const m=JSON.parse(raw);if(ws.waiters.length)ws.waiters.shift()(m);else ws.queue.push(m);});
   ws.next=()=>ws.queue.length?Promise.resolve(ws.queue.shift()):new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('message timeout')),2000);ws.waiters.push(m=>{clearTimeout(timer);resolve(m);});});
   await new Promise(r=>ws.once('open',r));ws.send(JSON.stringify(message)); return ws;
 }
 try {
   const a=await connect({type:'host',version:'1.0.2'});const welcome=await a.next(); assert.match(welcome.code,/^\d{4}$/);assert.equal(welcome.id,1);
   const b=await connect({type:'host',version:'1.0.2'});const other=await b.next();assert.notEqual(other.code,welcome.code);assert.equal(other.id,1);
   const bad=await connect({type:'join',code:welcome.code,version:'1.0.1'});assert.match((await bad.next()).message,/Version mismatch/);
   const guests=[];
   for(let i=2;i<=4;i++) { const ws=await connect({type:'join',code:welcome.code,version:'1.0.2'});assert.equal((await ws.next()).id,i);assert.equal((await a.next()).id,i);guests.push(ws); }
   const full=await connect({type:'join',code:welcome.code,version:'1.0.2'});assert.match((await full.next()).message,/full/);
   guests[0].send(JSON.stringify({type:'packet',to:1,method:'_choose_upgrade',data:'test'})); assert.deepEqual(await a.next(),{type:'packet',from:2,method:'_choose_upgrade',data:'test'});
   a.send(JSON.stringify({type:'packet',to:2,method:'_snapshot_chunk',data:'state'}));assert.equal((await guests[0].next()).data,'state');
   // The other host must never receive a packet from the first room.
   assert.equal(b.queue.length,0);assert.equal(guests[1].queue.length,0);
   a.send(JSON.stringify({type:'packet',to:0,method:'_start_run',data:'start'}));for(const ws of guests)assert.equal((await ws.next()).method,'_start_run');
   const late=await connect({type:'join',code:welcome.code,version:'1.0.2'});assert.match((await late.next()).message,/already started/);
   a.close();for(const ws of guests)assert.equal((await ws.next()).type,'closed');
   const missing=await connect({type:'join',code:welcome.code,version:'1.0.2'});assert.match((await missing.next()).message,/not found/);
   // A former guest can create a new room as host, using no listening port.
   const again=await connect({type:'host',version:'1.0.2'});assert.equal((await again.next()).id,1);
 } finally { for(const ws of clients)ws.terminate();relay.close(); }
});
