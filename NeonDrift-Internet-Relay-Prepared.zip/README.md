# Neon Drift internet relay

Prepared service; not deployed. No live URL is configured in the released game.

Run one always-on instance on a service supporting WebSockets with HTTPS/WSS on port 443. Both the host and guests make outbound connections; no player needs an inbound firewall rule or router port forwarding. Public Wi-Fi can still block the service itself, so unrestricted access on every network cannot be guaranteed.

Install Node 22+, run `npm ci`, then `npm start`. Hosting services should set PORT and use `/health` as a health check. Put it behind the host's HTTPS proxy and obtain its `wss://` URL. Do not expose an unencrypted `ws://` URL for internet use. Use a single replica; multiple replicas require a shared room coordinator. A restart closes all lobbies. Codes are four digits, random, unique among active rooms, and disappear when the host disconnects. A code is a convenience identifier, not a password: share it only with intended players and start after they join.

The matching Godot integration is prepared separately in the candidate source ZIP. Before a game release, set `network/relay_url` in project.godot to the live WSS endpoint and test two computers on the actual public Wi-Fi. Never ship a localhost or placeholder URL as though it were a working public service.

Game traffic stays within a room, clients can send only input/menu/upgrade messages to their host, versions must match, rooms have at most four pilots, and snapshot congestion, stale connections and message size/rate are bounded. This is a small friends-only relay, not a hardened public matchmaking platform. Hosting may incur charges; select a provider/plan before deployment.
